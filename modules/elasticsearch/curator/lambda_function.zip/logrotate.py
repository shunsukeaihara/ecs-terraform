import logging
import os
import curator
from elasticsearch import Elasticsearch, RequestsHttpConnection


logger = logging.getLogger('curator')
logger.addHandler(logging.StreamHandler())
logger.setLevel(logging.INFO)
es_host = os.environ["ES_HOST"]
es_index = os.environ["ES_INDEX_PREFIX"] + "-"
rotation_period = int(os.environ["ROTATION_PERIOD"])


def lambda_handler(event, context):
    es = Elasticsearch(
        hosts=[{"host": es_host, "port": 80}],
        use_ssl=False,
        verify_certs=True,
        connection_class=RequestsHttpConnection
    )
    runCurator(es)


def runCurator(es):
    ilo = curator.IndexList(es)
    ilo.filter_by_regex(kind="prefix", value=es_index)
    ilo.filter_by_age(source="name", direction="older", timestring="%Y.%m.%d", unit="days", unit_count=rotation_period)
    delete_indices = curator.DeleteIndices(ilo)
    try:
        delete_indices.do_action()
    except curator.exceptions.NoIndices:
        logger.info("no indeies for delete")
